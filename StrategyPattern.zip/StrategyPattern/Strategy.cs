﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StrategyPattern
{
    abstract class Strategy
    {
        public abstract void AlgorithmInterface();
    }
}
